offline_dictionary
==================

HTML5 Offline Dictionary and Thesaurus App

Based on Angular.JS . An Old Project of mine which I found in Archives. 
Special thanks to Adarsh J for helping in some crutial portions.

Licence: MIT
